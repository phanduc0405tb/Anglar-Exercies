import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aobout',
  templateUrl: './aobout.component.html',
  styleUrls: ['./aobout.component.css']
})
export class AoboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
